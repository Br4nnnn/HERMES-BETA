<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>HERMES</b> 0.0.1
    </div>
    <strong>2847523 &copy; HERMES <a href="https://adminlte.io">2847523</a>.</strong> Herramientas y equipos reservables para el manejo estratégico de servicios.
</footer>
