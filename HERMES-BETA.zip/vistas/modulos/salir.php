<?php
    session_destroy();
    echo '<script> window.location = "ingreso"; </script>';
?>