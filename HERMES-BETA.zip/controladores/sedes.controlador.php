<?php

class ControladorSedes
{

    static public function ctrCrearSede()
    {
        if (isset($_POST["nombreSede"]) && isset($_POST["direccionSede"]) && isset($_POST["descripcionSede"])) {
            if (preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["nombreSede"]) && preg_match('/^[a-zA-Z0-9ñÑáéíóúÁÉÍÓÚ ]+$/', $_POST["direccionSede"])) {

                $tabla = "sedes";
                $datos = array(
                    "nombre_sede" => $_POST["nombreSede"],
                    "direccion" => $_POST["direccionSede"],
                    "descripcion" => $_POST["descripcionSede"],
                );

                $respuesta = ModeloSedes::mdlCrearSedes($tabla, $datos);

                if ($respuesta == "ok") {
                    echo '<script>
                        Swal.fire({
                            icon: "success",
                            title: "¡La sede ha sido guardada correctamente!",
                            showConfirmButton: true,
                            confirmButtonText: "Cerrar"
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = "sedes";
                            }
                        });
                    </script>';
                } else {
                    echo '<script>
                        Swal.fire({
                            icon: "error",
                            title: "¡Error al crear la sede!",
                            showConfirmButton: true,
                            confirmButtonText: "Cerrar"
                        }).then((result) => {
                            if (result.isConfirmed) {
                                window.location = "sedes";
                            }
                        });
                    </script>';
                }
            } else {
                echo '<script>
                    Swal.fire({
                        icon: "error",
                        title: "¡Error al crear la sede!",
                        text: "¡No se permiten caracteres especiales!",
                        showConfirmButton: true,
                        confirmButtonText: "Cerrar"
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.location = "sedes";
                        }
                    });
                </script>';
            }
        }
        return;
    }

    static public function ctrMostrarSedes($item, $valor)
    {
        $tabla = "sedes";
        $respuesta = ModeloSedes::mdlMostrarSedes($tabla, $item, $valor);
        return $respuesta;
    }
}

