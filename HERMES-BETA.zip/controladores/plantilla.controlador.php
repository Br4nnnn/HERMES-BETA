<?php
class ControladorPlantilla {

    public function ctrPlantilla(){
        include "vistas/plantilla.php";
    }
}
?>